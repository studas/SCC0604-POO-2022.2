/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lista4ex04;

/**
 *
 * @author 12547792
 */
public class Lista4ex04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ContaCorrente conta =  new ContaCorrente();
        // TODO code application logic here
        try{
            conta.Depositar(-15f);
        }catch(DepositoInvalidoException exc){
            System.out.println(exc.getMessage()); 
        }
        conta.Sacar(15f);
        conta.SetValorLimite(20f);
        
    }

}
