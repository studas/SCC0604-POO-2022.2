/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lista4ex04;

/**
 *
 * @author 12547792
 */
public class ContaCorrente {

    float saldo = 0f;
    float creditoLimite = 0f;

    public void Sacar(float valor){
        saldo -= valor;
    }
    
    public void Depositar(float valor)  throws DepositoInvalidoException{
        if(valor <= 0){
            throw new DepositoInvalidoException();
        }else{
            saldo += valor;
        }
    }

    public void SetValorLimite(float valor){
        creditoLimite = valor;
    }

}


